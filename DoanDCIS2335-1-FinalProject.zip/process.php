<?php
$message = NULL;
	foreach ($_POST as $key=>$value){
		echo '<strong>'.$key.' : </strong>'.$value.'<br />'; 
		$message .= '<strong>'.$key.' : </strong>'.$value.'<br />';
	}
	$to = "drpatel8@uh.edu";
	$from = "DoNotReply@uh.edu";
	$bcc = "drpatel8@uh.edu";
	$subject = "CIS2336 Final Project";
	
	
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/plain;charset=UTF-8" . "r\n";
	$headers .= "From: <".$from.">\r\n";
	$headers .= "Bcc: ". $bcc ."\r\n";
	
	if(mail($to,$subject,$message,$headers)){
		$key = 'Successful';
	}else{
		$key = 'Unsuccessful';
		echo "Please try again";
	}
	
	 echo "<h1>Email Sent to $to was $key</h1>";
echo '<br /><br /><br /><br /><hr /><br />';
echo '<strong>REMOTE_ADDR : </strong> ' . $_SERVER['REMOTE_ADDR'] . '<br />';
echo '<strong>REMOTE_PORT : </strong> ' . $_SERVER['REMOTE_PORT'] . '<br />';
echo '<strong>SERVER_PORT : </strong> ' . $_SERVER['SERVER_PORT'] . '<br />';
echo '<strong>REQUEST_METHOD : </strong> ' . $_SERVER['REQUEST_METHOD'] . '<br />';
echo '<strong>HTTP_REFERER : </strong><a href="' . $_SERVER['HTTP_REFERER'] . '">' . $_SERVER['HTTP_REFERER'] . '</a><br />';
echo '<strong>HTTP_USER_AGENT  : </strong> ' . $_SERVER['HTTP_USER_AGENT'] . '<br />';	
?>
<a href="https://hndoan2.heyuhnem.com/index.html">Click here to return to main page</a>
